#!/bin/bash

# Funções para cada opção do sistema
check_processor() {
    echo "==================================="
    echo "       VERIFICAR PROCESSADOR"
    echo "==================================="
    lscpu | grep -E "Model name|Architecture|CPU\(s\)"
    echo ""
}

check_kernel() {
    echo "==================================="
    echo "          VERIFICAR KERNEL"
    echo "==================================="
    uname -a
    echo ""
}

check_installed_software() {
    echo "==================================="
    echo "    SOFTWARES INSTALADOS (TOP 10)"
    echo "==================================="
    # Verifica o gerenciador de pacotes
    if command -v dpkg &> /dev/null; then
        dpkg --list | head -20
    elif command -v rpm &> /dev/null; then
        rpm -qa | head -20
    else
        echo "Sistema não suportado para listar softwares"
    fi
    echo ""
}

check_os_version() {
    echo "==================================="
    echo "     VERSÃO DO SISTEMA OPERACIONAL"
    echo "==================================="
    if [ -f /etc/os-release ]; then
        cat /etc/os-release | grep -E "PRETTY_NAME|VERSION_ID|NAME"
    else
        cat /etc/*release* 2>/dev/null | head -5
    fi
    echo ""
}

check_memory() {
    echo "==================================="
    echo "          VERIFICAR MEMÓRIA"
    echo "==================================="
    free -h
    echo ""
}

check_serial() {
    echo "==================================="
    echo "       VERIFICAR SERIAL NUMBER"
    echo "==================================="
    # Tenta obter o serial number de diferentes formas
    if [ -f /sys/class/dmi/id/product_serial ]; then
        cat /sys/class/dmi/id/product_serial
    elif command -v dmidecode &> /dev/null; then
        sudo dmidecode -s system-serial-number 2>/dev/null || echo "Permissão necessária"
    else
        echo "Não foi possível obter o serial number"
    fi
    echo ""
}

check_ip() {
    echo "==================================="
    echo "       VERIFICAR IP DO SISTEMA"
    echo "==================================="
    # Obtém IPs de diferentes interfaces
    echo "Endereços IP:"
    ip addr show | grep -E "inet " | grep -v "127.0.0.1" | awk '{print "  " $2 " (" $7 ")"}'
    
    echo -e "\nIP Público (externo):"
    curl -s ifconfig.me 2>/dev/null || echo "Não foi possível obter IP externo"
    echo ""
}

# Menu do módulo Sistema
system_menu() {
    while true; do
        clear
        echo "==================================="
        echo "        MÓDULO SISTEMA"
        echo "==================================="
        echo "1 - Verificar processador"
        echo "2 - Verificar kernel"
        echo "3 - Verificar softwares instalados"
        echo "4 - Versão do sistema operacional"
        echo "5 - Verificar memória"
        echo "6 - Verificar serial number"
        echo "7 - Verificar IP do sistema"
        echo "0 - Voltar ao Menu Principal"
        echo "==================================="
        read -p "Escolha uma opção: " option
        
        case $option in
            1)
                check_processor
                ;;
            2)
                check_kernel
                ;;
            3)
                check_installed_software
                ;;
            4)
                check_os_version
                ;;
            5)
                check_memory
                ;;
            6)
                check_serial
                ;;
            7)
                check_ip
                ;;
            0)
                echo "Retornando ao Menu Principal..."
                sleep 1
                break
                ;;
            *)
                echo "Opção inválida!"
                ;;
        esac
        
        if [ "$option" != "0" ]; then
            echo "Pressione Enter para continuar..."
            read
        fi
    done
}

# Início do módulo Sistema
system_menu
