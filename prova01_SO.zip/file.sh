#!/bin/bash

# Funções para operações com arquivos
create_delete_files() {
    while true; do
        clear
        echo "==================================="
        echo "    CRIAR E APAGAR ARQUIVOS"
        echo "==================================="
        echo "1 - Criar arquivo"
        echo "2 - Apagar arquivo"
        echo "0 - Voltar"
        echo "==================================="
        read -p "Escolha uma opção: " option
        
        case $option in
            1)
                read -p "Nome do arquivo a criar: " filename
                if [ -z "$filename" ]; then
                    echo "Nome inválido!"
                elif [ -e "$filename" ]; then
                    echo "Arquivo já existe!"
                else
                    touch "$filename"
                    echo "Arquivo '$filename' criado com sucesso!"
                fi
                ;;
            2)
                read -p "Nome do arquivo a apagar: " filename
                if [ -z "$filename" ]; then
                    echo "Nome inválido!"
                elif [ ! -f "$filename" ]; then
                    echo "Arquivo não encontrado!"
                else
                    rm -i "$filename"
                    echo "Operação concluída!"
                fi
                ;;
            0)
                break
                ;;
            *)
                echo "Opção inválida!"
                ;;
        esac
        
        if [ "$option" != "0" ]; then
            echo "Pressione Enter para continuar..."
            read
        fi
    done
}

create_delete_directories() {
    while true; do
        clear
        echo "==================================="
        echo "  CRIAR E APAGAR DIRETÓRIOS"
        echo "==================================="
        echo "1 - Criar diretório"
        echo "2 - Apagar diretório"
        echo "0 - Voltar"
        echo "==================================="
        read -p "Escolha uma opção: " option
        
        case $option in
            1)
                read -p "Nome do diretório a criar: " dirname
                if [ -z "$dirname" ]; then
                    echo "Nome inválido!"
                elif [ -d "$dirname" ]; then
                    echo "Diretório já existe!"
                else
                    mkdir "$dirname"
                    echo "Diretório '$dirname' criado com sucesso!"
                fi
                ;;
            2)
                read -p "Nome do diretório a apagar: " dirname
                if [ -z "$dirname" ]; then
                    echo "Nome inválido!"
                elif [ ! -d "$dirname" ]; then
                    echo "Diretório não encontrado!"
                else
                    rm -ri "$dirname"
                    echo "Operação concluída!"
                fi
                ;;
            0)
                break
                ;;
            *)
                echo "Opção inválida!"
                ;;
        esac
        
        if [ "$option" != "0" ]; then
            echo "Pressione Enter para continuar..."
            read
        fi
    done
}

list_modify_permissions() {
    while true; do
        clear
        echo "==================================="
        echo "    LISTAR E MODIFICAR PERMISSÕES"
        echo "==================================="
        echo "1 - Listar permissões"
        echo "2 - Modificar permissões"
        echo "0 - Voltar"
        echo "==================================="
        read -p "Escolha uma opção: " option
        
        case $option in
            1)
                read -p "Nome do arquivo/diretório: " name
                if [ -z "$name" ] || [ ! -e "$name" ]; then
                    echo "Arquivo/diretório não encontrado!"
                else
                    echo "Permissões de '$name':"
                    ls -la "$name" | head -1
                fi
                ;;
            2)
                read -p "Nome do arquivo/diretório: " name
                if [ -z "$name" ] || [ ! -e "$name" ]; then
                    echo "Arquivo/diretório não encontrado!"
                else
                    echo "Permissões atuais:"
                    ls -la "$name" | head -1
                    read -p "Nova permissão (ex: 755, 644): " perm
                    if chmod "$perm" "$name" 2>/dev/null; then
                        echo "Permissões alteradas com sucesso!"
                    else
                        echo "Erro ao alterar permissões!"
                    fi
                fi
                ;;
            0)
                break
                ;;
            *)
                echo "Opção inválida!"
                ;;
        esac
        
        if [ "$option" != "0" ]; then
            echo "Pressione Enter para continuar..."
            read
        fi
    done
}

move_files_dirs() {
    while true; do
        clear
        echo "==================================="
        echo "    MOVER ARQUIVOS/DIRETÓRIOS"
        echo "==================================="
        echo "1 - Mover arquivo"
        echo "2 - Mover diretório"
        echo "0 - Voltar"
        echo "==================================="
        read -p "Escolha uma opção: " option
        
        case $option in
            1|2)
                read -p "Origem: " source
                read -p "Destino: " dest
                
                if [ -z "$source" ] || [ -z "$dest" ]; then
                    echo "Caminhos inválidos!"
                elif [ ! -e "$source" ]; then
                    echo "Origem não encontrada!"
                else
                    if mv "$source" "$dest" 2>/dev/null; then
                        echo "Movido com sucesso de '$source' para '$dest'!"
                    else
                        echo "Erro ao mover!"
                    fi
                fi
                ;;
            0)
                break
                ;;
            *)
                echo "Opção inválida!"
                ;;
        esac
        
        if [ "$option" != "0" ]; then
            echo "Pressione Enter para continuar..."
            read
        fi
    done
}

rename_files_dirs() {
    while true; do
        clear
        echo "==================================="
        echo "    RENOMEAR ARQUIVOS/DIRETÓRIOS"
        echo "==================================="
        echo "1 - Renomear arquivo"
        echo "2 - Renomear diretório"
        echo "0 - Voltar"
        echo "==================================="
        read -p "Escolha uma opção: " option
        
        case $option in
            1|2)
                read -p "Nome atual: " oldname
                read -p "Novo nome: " newname
                
                if [ -z "$oldname" ] || [ -z "$newname" ]; then
                    echo "Nomes inválidos!"
                elif [ ! -e "$oldname" ]; then
                    echo "'$oldname' não encontrado!"
                elif [ -e "$newname" ]; then
                    echo "'$newname' já existe!"
                else
                    if mv "$oldname" "$newname" 2>/dev/null; then
                        echo "Renomeado com sucesso de '$oldname' para '$newname'!"
                    else
                        echo "Erro ao renomear!"
                    fi
                fi
                ;;
            0)
                break
                ;;
            *)
                echo "Opção inválida!"
                ;;
        esac
        
        if [ "$option" != "0" ]; then
            echo "Pressione Enter para continuar..."
            read
        fi
    done
}

# Menu do módulo Arquivos
file_menu() {
    while true; do
        clear
        echo "==================================="
        echo "        MÓDULO ARQUIVOS"
        echo "==================================="
        echo "1 - Criar e apagar arquivos"
        echo "2 - Criar e apagar diretórios"
        echo "3 - Listar e modificar permissões"
        echo "4 - Mover arquivos e diretórios"
        echo "5 - Renomear arquivos e diretórios"
        echo "0 - Voltar ao Menu Principal"
        echo "==================================="
        read -p "Escolha uma opção: " option
        
        case $option in
            1)
                create_delete_files
                ;;
            2)
                create_delete_directories
                ;;
            3)
                list_modify_permissions
                ;;
            4)
                move_files_dirs
                ;;
            5)
                rename_files_dirs
                ;;
            0)
                echo "Retornando ao Menu Principal..."
                sleep 1
                break
                ;;
            *)
                echo "Opção inválida! Pressione Enter para continuar."
                read
                ;;
        esac
    done
}

# Início do módulo Arquivos
file_menu
