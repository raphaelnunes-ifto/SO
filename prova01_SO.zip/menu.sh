#!/bin/bash

# Função para limpar a tela
clear_screen() {
    clear
}

# Função principal do menu
main_menu() {
    while true; do
        clear_screen
        echo "==================================="
        echo "          MENU PRINCIPAL"
        echo "==================================="
        echo "a - Módulo Sistema"
        echo "b - Módulo Arquivos"
        echo "c - Encerrar"
        echo "==================================="
        read -p "Escolha uma opção: " option
        
        case $option in
            a|A)
                # Chama o módulo Sistema
                ./system.sh
                ;;
            b|B)
                # Chama o módulo Arquivos
                ./file.sh
                ;;
            c|C)
                clear_screen
                echo "Encerrando o programa..."
                exit 0
                ;;
            *)
                echo "Opção inválida! Pressione Enter para continuar."
                read
                ;;
        esac
    done
}

# Verifica se os scripts existem
check_scripts() {
    if [ ! -f "./system.sh" ]; then
        echo "Erro: system.sh não encontrado no diretório atual!"
        exit 1
    fi
    
    if [ ! -f "./file.sh" ]; then
        echo "Erro: file.sh não encontrado no diretório atual!"
        exit 1
    fi
    
}

# Início do programa
check_scripts
main_menu
